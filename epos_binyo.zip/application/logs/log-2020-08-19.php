<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-19 20:23:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'toko-nelli' C:\xampp\htdocs\Belajar\epos-master\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2020-08-19 20:23:24 --> Unable to connect to the database
ERROR - 2020-08-19 20:23:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'toko-nelli' C:\xampp\htdocs\Belajar\epos-master\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2020-08-19 20:23:39 --> Unable to connect to the database

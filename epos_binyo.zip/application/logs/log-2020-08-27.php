<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-27 11:28:07 --> 404 Page Not Found: api//index
ERROR - 2020-08-27 11:28:52 --> 404 Page Not Found: api/User/index
ERROR - 2020-08-27 11:40:54 --> 404 Page Not Found: api/Product/index

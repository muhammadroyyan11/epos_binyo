<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-09 19:50:35 --> Severity: 8192 --> strpos(): Non-string needles will be interpreted as strings in the future. Use an explicit chr() call to preserve the current behavior C:\xampp\htdocs\epos-master\application\third_party\MX\Router.php 239
ERROR - 2021-09-09 19:50:36 --> Severity: 8192 --> strpos(): Non-string needles will be interpreted as strings in the future. Use an explicit chr() call to preserve the current behavior C:\xampp\htdocs\epos-master\application\third_party\MX\Router.php 239
ERROR - 2021-09-09 19:50:36 --> Severity: 8192 --> strpos(): Non-string needles will be interpreted as strings in the future. Use an explicit chr() call to preserve the current behavior C:\xampp\htdocs\epos-master\application\third_party\MX\Router.php 239

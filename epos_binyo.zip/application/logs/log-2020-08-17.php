<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-17 15:28:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'toko-nelli' C:\xampp\htdocs\epos-master\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2020-08-17 15:28:21 --> Unable to connect to the database

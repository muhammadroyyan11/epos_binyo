<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-28 18:23:46 --> Query error: Unknown column 'L002' in 'where clause' - Invalid query: SELECT stock, ID FROM tb_product WHERE product_code = L002
ERROR - 2020-08-28 18:23:50 --> Query error: Unknown column 'L002' in 'where clause' - Invalid query: SELECT stock, ID FROM tb_product WHERE product_code = L002
ERROR - 2020-08-28 18:28:47 --> Query error: Unknown column 'L002' in 'where clause' - Invalid query: SELECT stock, ID FROM tb_product WHERE product_code = L002
ERROR - 2020-08-28 18:28:49 --> Query error: Unknown column 'L002' in 'where clause' - Invalid query: SELECT stock, ID FROM tb_product WHERE product_code = L002
ERROR - 2020-08-28 19:52:51 --> Query error: Unknown column 'L002' in 'where clause' - Invalid query: SELECT stock, ID FROM tb_product WHERE product_code = L002
ERROR - 2020-08-28 19:52:53 --> Query error: Unknown column 'L002' in 'where clause' - Invalid query: SELECT stock, ID FROM tb_product WHERE product_code = L002

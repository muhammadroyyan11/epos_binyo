<!DOCTYPE html>
<html>
   <head>
      <title><?php echo $title; ?></title>
      <link rel="stylesheet" href="<?php echo base_url("assets/dist/css/style-print.css?v=".md5(date('YmdH:i:s'))); ?>">
      <link rel="stylesheet" href="<?php echo base_url('assets/font-awesome/css/font-awesome.min.css'); ?>">
   </head>
   <body> <!--  onload="window.print()" -->
      <div class="content-wrap">
      <div class="wrapper">
         <div class="header">

         </div>
<div class="error-page">
  <h2 class="headline text-yellow"> 404</h2>
  <div class="error-content">
    <h3><i class="fa fa-warning text-yellow"></i> Halaman! tidak ditemukan.</h3>
  </div>
</div>
<style type="text/css">
.error-page .headline { margin-top:-40px; } .error-content { margin-top:50px; }
</style>